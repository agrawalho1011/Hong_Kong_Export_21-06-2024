﻿using APACExportTrackX.DataModel;
using APACExportTrackX.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using System.Globalization;
using System.ComponentModel;

namespace APACExportTrackX.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        ApplicationDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserController(ApplicationDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Index(string ActivityId)
        {
            var country = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var activity = _context.ActivityMaster.Where(x => x.Id == ActivityId && x.IsActive == true && x.IsDelete == false).FirstOrDefault();

            if (activity.ActivityType == "File")
            {
                activity.NameOfActivity += " (F)";
            }
            else
            {
                activity.NameOfActivity += " (H)";
            }

            ViewBag.Country = country;
            ViewBag.Activity = activity;
            return View();
        }

        public IActionResult Files(string activityId)
        {
            //ViewData["CountryId"] = _context.CountryMaster.ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.Id == activityId && x.IsActive == true && x.IsDelete == false).ToList();
            //ViewBag.Activity = activity;
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            //ViewBag.Countries = _context.CountryMaster.OrderBy(x => x.CountryName).ToList();
            return View();

        }

        //[HttpPost]
        //public IActionResult GetFiles(string country, string fileNumber, string activity, string search, string type)
        //{
        //    int totalRecord = 0;
        //    int filterRecord = 0;
        //    int hblrecord = 0;
        //    var draw = Request.Form["draw"].FirstOrDefault();
        //    var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
        //    var searchValue = Request.Form["search[value]"].FirstOrDefault();
        //    int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
        //    int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
        //    var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
        //    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

        //    var fileData = _context.ContainerMaster
        //        .Include(x => x.FileMaster)
        //        .Include(x => x.FileActivityLogs)
        //            .ThenInclude(x => x.ApplicationUser)
        //        .Select(a => new FileDashModel
        //        {
        //            Id = a.FileMaster.Id,
        //            FileLogId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id)
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //                .Select(y => y.Id)
        //                .FirstOrDefault(),
        //            EnterDate = a.FileMaster.EnterDate,
        //            FileNumber = a.FileMaster.FileNumber.Substring(0, a.FileMaster.FileNumber.Length - 6),
        //            POD = a.FileMaster.CountryMaster.CountryName,
        //            ETD = a.FileMaster.ETD,
        //            ETAPOD = a.FileMaster.ETAPOD,
        //            ETA = a.FileMaster.ETA,
        //            ATD = a.FileMaster.ATD,
        //            SICutOff = a.SICutOff,
        //            ShippingLine = a.FileMaster.ShippingLine,
        //            FileContact = a.FileMaster.FileContact,
        //            UserId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id)
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().ApplicationUser.UserName ?? "",
        //            StatusId = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            StatusCompleted = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().EndDate,
        //            ActivityId = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().Activity.NameOfActivity ?? "",
        //            ActivityType = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().Activity.ActivityType ?? "",
        //            ContainerNo = a.ContainerNo,
        //            ContainerId = a.Id,
        //            //TotalHBL = a.FileMaster.TotalBL,
        //            Comment = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //                    .ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                   .FirstOrDefault().Comment,
        //            //Roe = a.FileActivityLogs
        //            //        .Where(y => y.ContainerId == a.Id)
        //            //        .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //            //        .ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //            //       .FirstOrDefault().Roe,
        //            Roe = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Roe != null) // Filter for non-null Roe
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //                .ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Roe,
        //            CurrentUser = userName,
        //            EndDate = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id)
        //                .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
        //                .ThenBy(y => y.EndDate)
        //                .FirstOrDefault().EndDate,
        //            TallySheetId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TallySheetCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            MblReviewId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            MblReviewCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            TblProcessingId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            BLRequestId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TblProcessingCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            BLRequestCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            TallySheetComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            MblReviewComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            TblProcessingComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            BLRequestComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            CarrierRequest = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            CarrierRequestCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .FirstOrDefault().EndDate,
        //            BlRequestId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            BlRequestCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "BL Request")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .FirstOrDefault().EndDate,
        //            TBLProcessing = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TBLProcessCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .FirstOrDefault().EndDate,
        //            TallySheetChecking = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TallySheetCheckingCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .FirstOrDefault().EndDate,
        //            SIToCarrier = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            SIToCarrierCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .FirstOrDefault().EndDate,
        //            MBLReview = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "MBL Review")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "MBL Review")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            MBLReviewsCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "MBL Review")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "MBL Review")
        //            .FirstOrDefault().EndDate,
        //            Invoice = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            InvoiceCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .FirstOrDefault().EndDate,
        //            FinalBL = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            FinalBLCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .FirstOrDefault().EndDate,
        //            PreAlert = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            PreAlertCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .FirstOrDefault().EndDate,
        //            Permit = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Permit")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Permit")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            PermitCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Permit")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Permit")
        //            .FirstOrDefault().EndDate,
        //            LBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count(),
        //            TBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
        //            TotalHBL = a.HBLMasters.Where(y => y.ContainerId == a.Id).Count() != 0 ? (a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : a.FileMaster.TotalBL

        //        }).AsQueryable();

        //    IQueryable<FileDashModel> data = fileData.AsQueryable();
        //    DateTime date = DateTime.UtcNow;
        //    if (!string.IsNullOrEmpty(fileNumber))
        //    {
        //        data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
        //    }
        //    if (date != null)
        //    {
        //        data = data.Where(x => x.SICutOff.Value.Date >= date.Date || x.SICutOff.Value.Date == null);
        //    }
        //    if (activity == "BL Request")
        //    {
        //        data = data.Where(x => x.BlRequestId != "Completed" && x.CarrierRequest == "Completed");
        //    }
        //    if (activity == "SI To Carrier")
        //    {
        //        data = data.Where(x => x.SIToCarrier != "Completed" && x.BlRequestId == "Completed");
        //    }
        //    else if (activity == "Final BL To Invoices Customer")
        //    {
        //        data = data.Where(x => x.FinalBL != "Completed" && x.SIToCarrier == "Completed");
        //    }
        //    else if (activity == "Pre-Alert")
        //    {
        //        data = data.Where(x => x.FinalBL == "Completed" && x.PreAlert != "Completed");
        //    }
        //    else if (activity == "Permit")
        //    {
        //        data = data.Where(x => x.PreAlert == "Completed" && x.Permit != "Completed");
        //    }
        //    else if (activity == "Invoices To POD Agent")
        //    {
        //        data = data.Where(x => x.Permit == "Completed" && x.Invoice != "Completed");
        //    }
        //    else if (activity == "Tally Sheet")
        //    {
        //        data = data.Where(x => x.CarrierRequest == "Completed" && x.TallySheetId != "Completed");
        //    }
        //    else if (activity == "MBL Review")
        //    {
        //        data = data.Where(x => x.CarrierRequest == "Completed" && x.MblReviewId != "Completed");
        //    }
        //    else if (activity == "TBL Processing")
        //    {
        //        data = data.Where(x => x.CarrierRequest == "Completed" && x.TBLProcessing != "Completed");
        //    }
        //    else
        //    {
        //        data = data.Where(x => (x.ActivityId == activity.Trim() && x.StatusId != "Completed"));
        //    }

        //    if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
        //    {
        //        data = data.Where(x => x.POD == country);
        //    }

        //    if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
        //    {
        //        data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
        //    }
        //    else if (activity == "SI To Carrier")
        //    {
        //        sortColumn = "siCutOff";
        //        data = data.OrderByDescending(x => x.StatusId == "Pending" && x.UserId == userName).ThenBy(sortColumn + " " + sortColumnDirection);
        //    }
        //    else if (activity == "Final BL To Invoices Customer")
        //    {
        //        sortColumn = "etd";
        //        data = data.OrderByDescending(x => x.StatusId == "Pending" && x.UserId == userName).ThenBy(sortColumn + " " + sortColumnDirection);
        //    }
        //    else
        //    {
        //        sortColumn = "enterDate";

        //        data = data.OrderByDescending(x => x.StatusId == "Pending" && x.UserId == userName).ThenBy(sortColumn + " " + sortColumnDirection);
        //    }

        //    var files = data.Skip(skip).Take(pageSize).ToList();

        //    return Json(new
        //    {
        //        draw = draw,
        //        recordsTotal = fileData.Count(),
        //        recordsFiltered = files.Count(),
        //        data = files
        //    });

        //}

        [HttpPost]
        public IActionResult GetFiles(string country, string fileNumber, string activity, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var fileData = _context.ContainerMaster
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(a => new FileDashModel
                {
                    Id = a.FileMaster.Id,
                    FileLogId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id)
                        .Select(y => y.Id)
                        .FirstOrDefault(),
                    EnterDate = a.FileMaster.EnterDate,
                    FileNumber = a.FileMaster.FileNumber.Substring(0, a.FileMaster.FileNumber.Length - 6),
                    POD = a.FileMaster.CountryMaster.CountryName,
                    ETD = a.FileMaster.ETD,
                    ETAPOD = a.FileMaster.ETAPOD,
                    ETA = a.FileMaster.ETA,
                    ATD = a.FileMaster.ATD,
                    SICutOff = a.SICutOff,
                    ShippingLine = a.FileMaster.ShippingLine,
                    FileContact = a.FileMaster.FileContact,
                    UserId = a.FileActivityLogs.Where(y => y.ContainerId == a.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                            .FirstOrDefault().Status.Status ?? "UnAllocated",
                    StatusCompleted = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                            .FirstOrDefault().EndDate,
                    ActivityId = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                            .FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                            .FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = a.ContainerNo,
                    ContainerId = a.Id,
                    //TotalHBL = a.FileMaster.TotalBL,
                    Comment = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                           .FirstOrDefault().Comment,
                    //Roe = a.FileActivityLogs
                    //        .Where(y => y.ContainerId == a.Id)
                    //        .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //        .ThenByDescending(y => y.Activity.NameOfActivity == activity)
                    //       .FirstOrDefault().Roe,
                    Roe = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Roe != null)
                        .FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id)
                        .FirstOrDefault().EndDate,
                    SIToCarrier = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIToCarrierCompleted = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().EndDate,
                    OBDDN = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Status.Status ?? "UnAllocated",
                    OBDDNCompleted = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().EndDate,
                    Telex = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "COB").FirstOrDefault().Status.Status ?? "UnAllocated",
                    TelexCompleted = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "COB").FirstOrDefault().EndDate,
                    Invoice = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "AMS Filing").FirstOrDefault().Status.Status ?? "UnAllocated",
                    InvoiceCompleted = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "AMS Filing").FirstOrDefault().EndDate,
                    PreAlert = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().Status.Status ?? "UnAllocated",
                    PreAlertCompleted = a.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().EndDate,
                    LBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("HKG")).Count(),
                    TBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("HKG")).Count(),
                    TotalHBL = a.HBLMasters.Where(y => y.ContainerId == a.Id).Count() != 0 ? (a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("HKG")).Count()) + (a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("HKG")).Count()) : a.FileMaster.TotalBL

                }).AsQueryable();

            IQueryable<FileDashModel> data = fileData.AsQueryable();
            DateTime date = DateTime.UtcNow;
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (date != null)
            {
                data = data.Where(x => x.SICutOff >= date.Date - TimeSpan.FromDays(10) || x.SICutOff == null);
            }
            if (activity == "AMS Filing")
            {
                data = data.Where(x => x.Invoice != "Completed" && x.OBDDN == "Completed");
            }
            else if (activity == "SI To Carrier")
            {
                data = data.Where(x => x.SIToCarrier != "Completed");
            }
            else if (activity == "Pre-Alert")
            {
                data = data.Where(x => x.OBDDN == "Completed" && x.PreAlert != "Completed");
            }
            else if (activity == "COB")
            {
                data = data.Where(x => x.OBDDN == "Completed" && x.Telex != "Completed");
            }
            //else if (activity == "Telex")
            //{
            //    data = data.Where(x => x.Invoice == "Completed" && x.Telex != "Completed");
            //}
            else if (activity == "MBL Review")
            {
                data = data.Where(x => x.SIToCarrier == "Completed" && x.OBDDN != "Completed");
            }
            else
            {
                data = data.Where(x => (x.ActivityId == activity.Trim() && x.SIToCarrier != "Completed"));
            }

            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (activity == "SI To Carrier")
            {
                sortColumn = "siCutOff";
                data = data.OrderByDescending(x => x.StatusId == "Pending").ThenBy(sortColumn + " " + sortColumnDirection);
            }
            else if (activity == "Invoice")
            {
                sortColumn = "etd";
                data = data.OrderByDescending(x => x.StatusId == "Pending").ThenBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";

                data = data.OrderByDescending(x => x.StatusId == "Pending").ThenBy(sortColumn + " " + sortColumnDirection);
            }

            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            data = data.Select(a => new FileDashModel
            {
                Id = a.Id,
                FileLogId = a.FileLogId,
                EnterDate = a.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EnterDate.Value, istTimeZone) : (DateTime?)null,
                FileNumber = a.FileNumber,
                POD = a.POD,
                ETD = a.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETD.Value, istTimeZone) : (DateTime?)null,
                ETAPOD = a.ETAPOD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETAPOD.Value, istTimeZone) : (DateTime?)null,
                ETA = a.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETA.Value, istTimeZone) : (DateTime?)null,
                ATD = a.ATD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ATD.Value, istTimeZone) : (DateTime?)null,
                SICutOff = a.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.SICutOff.Value, istTimeZone) : (DateTime?)null,
                ShippingLine = a.ShippingLine,
                FileContact = a.FileContact,
                UserId = a.UserId,
                StatusId = a.StatusId,
                StatusCompleted = a.StatusCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.StatusCompleted.Value, istTimeZone) : (DateTime?)null,
                ActivityId = a.ActivityId,
                ActivityType = a.ActivityType,
                ContainerNo = a.ContainerNo,
                ContainerId = a.ContainerId,
                Comment = a.Comment,
                Roe = a.Roe,
                CurrentUser = a.CurrentUser,
                EndDate = a.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EndDate.Value, istTimeZone) : (DateTime?)null,
                OBDDN = a.OBDDN,
                OBDDNCompleted = a.OBDDNCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.OBDDNCompleted.Value, istTimeZone) : (DateTime?)null,
                Telex = a.Telex,
                TelexCompleted = a.TelexCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.TelexCompleted.Value, istTimeZone) : (DateTime?)null,
                SIToCarrier = a.SIToCarrier,
                SIToCarrierCompleted = a.SIToCarrierCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.SIToCarrierCompleted.Value, istTimeZone) : (DateTime?)null,
                Invoice = a.Invoice,
                InvoiceCompleted = a.InvoiceCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.InvoiceCompleted.Value, istTimeZone) : (DateTime?)null,
                PreAlert = a.PreAlert,
                PreAlertCompleted = a.PreAlertCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.PreAlertCompleted.Value, istTimeZone) : (DateTime?)null,
                LBL = a.LBL,
                TBL = a.TBL,
                TotalHBL = a.TotalHBL
            }).AsQueryable();

            //var files = data.Skip(skip).Take(pageSize).ToList();
            var files = data.ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = fileData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });

        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(hblact);
        }

        [HttpGet]
        public IActionResult HBL(string activityId, string fileNumber)
        {
            ViewData["CountryId"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetHBLs(string country, string fileNumber, string activity, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            _context.Database.SetCommandTimeout(300);
            var hblData = _context.HBLMaster
                .Include(x => x.HBLActivityLogs)
                .Include(x => x.ContainerMaster)
                .Include(x => x.ContainerMaster.FileMaster.CountryMaster)
                .Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    HBLNumber = x.HBLNumber,
                    FileId = x.Id,
                    EnterDate = x.EnterDate,
                    POD = x.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    FileNumber = x.ContainerMaster.FileMaster.FileNumber.Substring(0, x.ContainerMaster.FileMaster.FileNumber.Length - 6),
                    ContainerNo = x.ContainerMaster.ContainerNo,
                    SICutOff = x.ContainerMaster.SICutOff,
                    BookingNo = x.Booking,
                    CustomerName = x.CustomerName,
                    AMSDetails = x.AMSDetails,
                    AMSStatus = x.AMSStatus,
                    CurrentUser = userid,
                    Activity = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Activity.NameOfActivity).FirstOrDefault() ?? "",
                    ActivityType = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Activity.ActivityType).FirstOrDefault() ?? "",
                    User = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.ApplicationUser.UserName).FirstOrDefault() ?? "",
                    Status = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Status.Status).FirstOrDefault() ?? "UnAllocated",
                    Comment = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Comment).FirstOrDefault() ?? "",
                    StartDate = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.StartDate).FirstOrDefault(),
                    EndDate = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.EndDate).FirstOrDefault()
                }).AsQueryable();
            IQueryable<HBLDashViewModel> data = hblData.AsQueryable();
            DateTime date = DateTime.UtcNow;
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (date != null)
            {
                data = data.Where(x => x.SICutOff >= date.Date - TimeSpan.FromDays(10) || x.SICutOff == null);
            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                data = data.Where(x => string.IsNullOrEmpty(x.Activity) && string.IsNullOrEmpty(x.ActivityType) || x.Activity != activity && x.ActivityType != type);
            }

            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }

            if(string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "hblNumber";
                sortColumnDirection = "asc";
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            data = data.Select(x => new HBLDashViewModel
            {
                Id = x.Id,
                HBLNumber = x.HBLNumber,
                FileId = x.Id,
                EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, istTimeZone) : (DateTime?)null,
                POD = x.POD,
                FileNumber = x.FileNumber,
                ContainerNo = x.ContainerNo,
                BookingNo = x.BookingNo,
                CustomerName = x.CustomerName,
                AMSDetails = x.AMSDetails,
                AMSStatus = x.AMSStatus,
                CurrentUser = userid,
                Activity = x.Activity,
                ActivityType = x.ActivityType,
                User = x.User,
                Status = x.Status,
                Comment = x.Comment,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null
            }).AsQueryable();


            //var files = data.ToList();
            //.Skip(skip)
            //.Take(pageSize)
            //.ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = hblData.Count(),
                recordsFiltered = data.ToList().Count(),
                data = data.ToList()
            });
        }

        [HttpGet]
        public IActionResult GetFileActivityData(string Id)
        {
            var adhocFile = _context.AdhocFileActivityLog.Where(fileActivity => fileActivity.AdhocFile.Id == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            return Json(new { adhocFile });
        }

        [HttpGet]
        public IActionResult GetHBLActivityData(string Id)
        {
            var adhocHBL = _context.AdhocHBLActivityLog.Where(fileActivity => fileActivity.AdhocHBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();


            return Json(new { adhocHBL });
        }

        [HttpGet]
        public IActionResult GetHBLActivity(string Id)
        {
            var HBL = _context.HBLActivityLog.Where(x => x.HBLId == Id)
            .Include(activity => activity.Activity)
            .Include(status => status.Status)
            .Include(user => user.ApplicationUser)
            .Select(x => new
            {
                Id = x.Activity.Id,
                ActivityName = x.Activity.NameOfActivity,
                Status = x.Status.Status,
                ProcessedDate = x.EndDate,
                User = x.ApplicationUser.UserName,
                Comment = x.Comment == null ? "" : x.Comment,
            })
           .OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable()
           .ToList();

            HBL = HBL.Select(x => new
            {
                Id = x.Id,
                ActivityName = x.ActivityName,
                Status = x.Status,
                ProcessedDate = x.ProcessedDate,
                User = x.User,
                Comment = x.Comment,
            }).AsQueryable().ToList();


            return Json(new { HBL });
        }


        [HttpGet]
        public IActionResult GetHblActivitiesData(string hblId)
        {
            ViewData["hblActivityList"] = _context.HBLActivityLog.Where(x => x.HBLId == hblId).Select(x => new HBLActivityLogViewModel
            {
                HBLId = x.HBLId,
                HBLNumber = x.Hbl.HBLNumber == null ? "" : x.Hbl.HBLNumber,
                ActivityId = x.Activity.NameOfActivity,
                EndDate = x.EndDate,
                StatusId = x.Status.Status,
                Comment = x.Comment == null ? "" : x.Comment,
                UserId = x.ApplicationUser.CitrixId == null ? "" : x.ApplicationUser.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivitiesData(string hblno, string hbl)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Where(x => x.Hbl.HBLNumber == hblno).ToList();
            List<HBLActivityLogViewModel> hblActivityLog = new List<HBLActivityLogViewModel>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityLogViewModel
                {
                    HBLNumber = hblno == null ? "" : hblno,
                    ActivityId = item.Activity.NameOfActivity == null ? "" : item.Activity.NameOfActivity,
                    EndDate = item.EndDate,
                    StatusId = item.Status.Status,
                    UserId = item.ApplicationUser.CitrixId,

                });
            }
            return Json(hblActivityLog);
        }

        [HttpPost]
        public JsonResult AddFileActivities(FileActivityLogViewModel model, string button, string? statusValue, string? endDateValue, string? fileComments, string? roeValue, string? etdValue, string? atdValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var editData = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.ContainerId == model.ContainerId && x.ActivityId == model.ActivityId);
            var wip = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == "WIP");
            var wipId = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == "WIP")?.Id;
            var query = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == "Query")?.Id;
            var pending = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == "Pending")?.Id;
            var completed = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == "Completed")?.Id;
            var completedWithQuery = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == "Completed With Query")?.Id;
            var SIToCarrier = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.NameOfActivity == "SI To Carrier")?.Id;
            var TelexId = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.NameOfActivity == "COB")?.Id;
            var statusList = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == statusValue);
            var fileList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).FirstOrDefault(x => x.ContainerId == model.ContainerId && x.ActivityId == model.ActivityId);
            var userList = _context.Users.FirstOrDefault(x => x.UserName == model.UserId);

            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;

            if(model.StartDate.Contains("01 Jan 1"))
            {
                model.StartDate = "01 Jan 2000 00:00";
            }
            if (etdValue.Contains("01 Jan 1"))
            {
                etdValue = "01 Jan 2000 00:00";
            }
            if (atdValue.Contains("01 Jan 1"))
            {
                atdValue = "01 Jan 2000 00:00";
            }
            if (model.StartDate != null)
            {
                DateTime startDate = DateTime.ParseExact(model.StartDate, "dd MMM yyyy HH:mm", CultureInfo.InvariantCulture);
                model.StartDate = startDate.ToString("MM/dd/yyyy HH:mm");
            }

            if (atdValue != null)
            {
                DateTime atd = DateTime.ParseExact(atdValue, "dd MMM yyyy HH:mm", CultureInfo.InvariantCulture);
                atdValue = atd.ToString("MM/dd/yyyy HH:mm");
            }
            if (etdValue != null)
            {
                DateTime etd = DateTime.ParseExact(etdValue, "dd MMM yyyy HH:mm", CultureInfo.InvariantCulture);
                etdValue = etd.ToString("MM/dd/yyyy HH:mm");
            }
            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    if (model.StatusId != wip.Status || model.UserId == userName)
                    {
                        if (fileList != null)
                        {
                            fileList.ContainerId = model.ContainerId;
                            fileList.ActivityId = model.ActivityId;
                            fileList.StatusId = wip.Id;
                            fileList.UserId = userid;
                            fileList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                            fileList.Roe = model.Roe;
                            _context.FileActivityLog.Update(fileList);
                        }
                        else
                        {
                            var containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                            if (containerData == null)
                            {
                                _context.ContainerMaster.Add(new ContainerMaster
                                {
                                    ContainerNo = model.ContainerNo,
                                    FileId = model.FileId,
                                    SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                                });
                                _context.SaveChanges();

                                containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                            }

                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = containerData.Id,
                                ActivityId = model.ActivityId,
                                StatusId = (model.StatusId != wip.Status) ? wip.Id : model.StatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                Roe = model.Roe
                            });
                            _context.SaveChanges();
                        }
                        _context.SaveChanges();
                        return Json("Success");
                    }
                    else
                    {
                        return Json("Activity is processed by another user");
                    }
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    var user = "";
                    if (model.StatusId == "UnAllocated" || statusValue == "UnAllocated")
                    {
                        user = null;
                    }
                    else
                    {
                        user = userid;
                    }
                    if (fileList != null)
                    {
                        fileList.ContainerId = model.ContainerId;
                        fileList.ActivityId = model.ActivityId;
                        fileList.StatusId = selectedStatusId;
                        fileList.UserId = user;
                        fileList.Roe = roeValue;
                        fileList.ContainerMaster.FileMaster.ETD = Convert.ToDateTime(etdValue).ToUniversalTime();
                        fileList.ContainerMaster.FileMaster.ATD = Convert.ToDateTime(atdValue).ToUniversalTime();
                        _context.FileActivityLog.Update(fileList);
                        _context.FileMaster.Update(fileList.ContainerMaster.FileMaster);
                    }
                    else
                    {
                        var containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                        if (containerData == null)
                        {
                            _context.ContainerMaster.Add(new ContainerMaster
                            {
                                ContainerNo = model.ContainerNo,
                                FileId = model.FileId,
                                SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                            });
                            _context.SaveChanges();

                            containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                        }
                        else
                        {
                            containerData.ContainerNo = model.ContainerNo;
                            containerData.FileId = model.FileId;
                            containerData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                            containerData.FileMaster.ETD = Convert.ToDateTime(model.ETD).ToUniversalTime();
                            containerData.FileMaster.ATD = Convert.ToDateTime(model.ATD).ToUniversalTime();
                            _context.ContainerMaster.Update(containerData);
                            _context.FileMaster.Update(containerData.FileMaster);
                        }

                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = containerData.Id,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = user,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment,
                            Roe = roeValue
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else
            {
                var fileListData = _context.FileMaster.FirstOrDefault(x => x.Id == model.FileId);
                var containerListData = _context.ContainerMaster.FirstOrDefault(x => (x.ContainerNo == model.ContainerNo && x.FileId == model.FileId) || (x.ContainerNo == null && x.FileId == model.FileId));
                var sIToCarrier = _context.ActivityMaster.Where(x => x.NameOfActivity == "SI To Carrier" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var telex = _context.ActivityMaster.Where(x => x.NameOfActivity == "COB" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var obddn = _context.ActivityMaster.Where(x => x.NameOfActivity == "MBL Review" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var invoice = _context.ActivityMaster.Where(x => x.NameOfActivity == "AMS Filing" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var preAlert = _context.ActivityMaster.Where(x => x.NameOfActivity == "Pre-Alert" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();

                if (containerListData != null)
                {
                    containerListData = _context.ContainerMaster.FirstOrDefault(x => (x.ContainerNo == model.ContainerNo && x.FileId == model.FileId) || (x.ContainerNo == null && x.FileId == model.FileId));

                    _context.ContainerMaster.Update(containerListData);
                    _context.SaveChanges();

                }
                else
                {
                    _context.ContainerMaster.Add(new ContainerMaster
                    {
                        ContainerNo = model.ContainerNo,
                        SICutOff = DateTime.UtcNow.AddDays(10),
                        FileId = model.FileId,
                    });
                    _context.SaveChanges();

                    containerListData = _context.ContainerMaster.FirstOrDefault(x => (x.ContainerNo == model.ContainerNo && x.FileId == model.FileId) || (x.ContainerNo == null && x.FileId == model.FileId));
                    //_context.SaveChanges();
                    _context.FileActivityLog.Add(new FileActivityLog
                    {
                        ContainerId = containerListData.Id,
                        ActivityId = SIToCarrier,
                        StatusId = model.StatusId,
                        UserId = null,
                        StartDate = null,
                        EndDate = null,
                        Comment = null
                    });
                    _context.SaveChanges();

                }

                //var sIToCarrier = _context.ActivityMaster.Where(x => x.NameOfActivity == "SI To Carrier" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                //var telex = _context.ActivityMaster.Where(x => x.NameOfActivity == "COB" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                //var obddn = _context.ActivityMaster.Where(x => x.NameOfActivity == "MBL Review" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                //var invoice = _context.ActivityMaster.Where(x => x.NameOfActivity == "AMS Filing" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                //var preAlert = _context.ActivityMaster.Where(x => x.NameOfActivity == "Pre-Alert" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId != TelexId).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                var fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                if (ModelState.IsValid)
                {
                    if (sIToCarrier != null)
                    {
                        var hblList = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Hbl.ContainerId == containerListData.Id).ToList();
                        foreach (var hbl in hblList)
                        {
                            if (hbl.Status.Status != "Completed")
                            {
                                return Json("Please complete HBL activities.");
                            }
                        }

                        if (containerListData != null)
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();
                            var activities = new List<(string ActivityId, string StatusId, string Comment)>();
                            if (model.ActivityId == obddn)
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                                {
                                    //(model.ActivityId, model.StatusId, model.Comment),
                                    //(TelexId, model.TelexId, model.TelexComment)
                                    (model.ActivityId, model.StatusId, model.Comment),
                                };
                            }
                            else
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                                {
                                    (model.ActivityId, model.StatusId, model.Comment),
                                };
                            }

                            //var activityIds = new List<string>
                            //        {
                            //            TelexId
                            //        };
                            var statusIds = new List<string>
                                {
                                    completedWithQuery,
                                    completed,
                                    pending,
                                    query
                                };
                            List<FileActivityLog> fileActivityLog = new List<FileActivityLog>();
                            int count = 0;
                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                if (activityId != obddn)
                                {
                                    if (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query)
                                    {
                                        fileActivityLog = _context.FileActivityLog.Where(x =>
                                        x.ContainerId == containerListData.Id &&
                                        x.ActivityId == activityId).ToList();

                                        count++;

                                    }
                                }
                            }

                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                var fileLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.ContainerMaster)
                                    .FirstOrDefault(x => x.ContainerId == containerListData.Id && x.ActivityId == activityId);
                                if (model.ActivityId == obddn)
                                {

                                    if (count >= 0)
                                    {
                                        if (fileLog != null)
                                        {
                                            containerListData.ContainerNo = model.ContainerNo;
                                            containerListData.FileId = model.FileId;
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            fileListData.ETD = Convert.ToDateTime(model.ETD).ToUniversalTime();
                                            fileListData.ATD = Convert.ToDateTime(model.ATD).ToUniversalTime();
                                            fileLog.ActivityId = activityId;
                                            fileLog.StatusId = statusId;
                                            fileLog.UserId = userid;
                                            fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                            fileLog.EndDate = DateTime.UtcNow;
                                            fileLog.Comment = comment;
                                            fileLog.Roe = model.Roe;
                                            _context.FileActivityLog.Update(fileLog);
                                            _context.ContainerMaster.Update(containerListData);
                                            _context.FileMaster.Update(fileListData);
                                            _context.SaveChanges();
                                        }
                                        else if (activityId == TelexId)
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                        else
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                    }
                                    else
                                    {
                                        return Json("Please complete Telex activity.");
                                    }


                                }
                                else
                                {
                                    if (fileLog != null)
                                    {
                                        containerListData.ContainerNo = model.ContainerNo;
                                        containerListData.FileId = model.FileId;
                                        containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                        fileListData.ETD = Convert.ToDateTime(model.ETD).ToUniversalTime();
                                        fileListData.ATD = Convert.ToDateTime(model.ATD).ToUniversalTime();
                                        fileLog.ActivityId = activityId;
                                        fileLog.StatusId = statusId;
                                        fileLog.UserId = userid;
                                        fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                        fileLog.EndDate = DateTime.UtcNow;
                                        fileLog.Comment = comment;
                                        fileLog.Roe = model.Roe;
                                        _context.FileActivityLog.Update(fileLog);
                                        _context.ContainerMaster.Update(containerListData);
                                        _context.FileMaster.Update(fileListData);
                                        _context.SaveChanges();
                                    }
                                    else if (activityId == TelexId)
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                        _context.SaveChanges();
                                    }
                                    else
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                            EndDate = DateTime.UtcNow,
                                            Comment = comment,
                                            Roe = model.Roe
                                        });
                                        _context.SaveChanges();
                                    }
                                }

                            }

                            _context.SaveChanges();

                            lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                            fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                            var fileActivityLists = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();
                            if (fileActivityLists != null)
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == sIToCarrier)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == obddn).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = obddn,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == obddn)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoice).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = invoice,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == telex)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }

                            }
                            else 
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                        else
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();

                            var containersListData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                            _context.ContainerMaster.Add(new ContainerMaster
                            {
                                ContainerNo = model.ContainerNo,
                                FileId = model.FileId,
                                SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                            });
                            _context.SaveChanges();

                            var containerData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = containerData.Id,
                                ActivityId = model.ActivityId,
                                StatusId = model.StatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                Roe = model.Roe
                            });

                            _context.SaveChanges();

                            lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                            fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                            var fileActivityLists = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();
                            if (fileActivityLists != null)
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == sIToCarrier)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == obddn).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = obddn,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == obddn)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoice).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = invoice,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == telex)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }

                            }
                            else
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                    }
                    else
                    {
                        if (containerListData != null)
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();
                            var activities = new List<(string ActivityId, string StatusId, string Comment)>();
                            if (model.ActivityId == obddn)
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                            {
                                //(model.ActivityId, model.StatusId, model.Comment),
                                //(TelexId, model.TelexId, model.TelexComment)
                                (model.ActivityId, model.StatusId, model.Comment),
                            };
                            }
                            else
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                            {
                                (model.ActivityId, model.StatusId, model.Comment),
                            };
                            }

                            //var activityIds = new List<string>
                            //        {
                            //            TelexId
                            //        };
                            var statusIds = new List<string>
                                {
                                    completedWithQuery,
                                    completed,
                                    pending,
                                    query
                                };
                            List<FileActivityLog> fileActivityLog = new List<FileActivityLog>();
                            int count = 0;
                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                if (activityId != obddn)
                                {
                                    if (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query)
                                    {
                                        fileActivityLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x =>
                                        x.ContainerId == containerListData.Id &&
                                        x.ActivityId == activityId).ToList();

                                        count++;

                                    }
                                }
                            }

                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                var fileLog = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status)
                                    .FirstOrDefault(x => x.ContainerId == containerListData.Id && x.ActivityId == activityId);
                                if (model.ActivityId == obddn)
                                {

                                    if (count >= 0)
                                    {
                                        if (fileLog != null)
                                        {
                                            containerListData.ContainerNo = model.ContainerNo;
                                            containerListData.FileId = model.FileId;
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            fileListData.ETD = Convert.ToDateTime(model.ETD).ToUniversalTime();
                                            fileListData.ATD = Convert.ToDateTime(model.ATD).ToUniversalTime();
                                            fileLog.ActivityId = activityId;
                                            fileLog.StatusId = statusId;
                                            fileLog.UserId = userid;
                                            fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                            fileLog.EndDate = DateTime.UtcNow;
                                            fileLog.Comment = comment;
                                            fileLog.Roe = model.Roe;
                                            _context.FileActivityLog.Update(fileLog);
                                            _context.ContainerMaster.Update(containerListData);
                                            _context.FileMaster.Update(fileListData);
                                            _context.SaveChanges();
                                        }
                                        else if (activityId == TelexId)
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                        else
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                    }
                                    else
                                    {
                                        return Json("Please complete Telex activity.");
                                    }


                                }
                                else
                                {
                                    if (fileLog != null)
                                    {
                                        containerListData.ContainerNo = model.ContainerNo;
                                        containerListData.FileId = model.FileId;
                                        containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                        fileListData.ETD = Convert.ToDateTime(model.ETD).ToUniversalTime();
                                        fileListData.ATD = Convert.ToDateTime(model.ATD).ToUniversalTime();
                                        fileLog.ActivityId = activityId;
                                        fileLog.StatusId = statusId;
                                        fileLog.UserId = userid;
                                        fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                        fileLog.EndDate = DateTime.UtcNow;
                                        fileLog.Comment = comment;
                                        fileLog.Roe = model.Roe;
                                        _context.FileActivityLog.Update(fileLog);
                                        _context.ContainerMaster.Update(containerListData);
                                        _context.FileMaster.Update(fileListData);
                                        _context.SaveChanges();
                                    }
                                    else if (activityId == TelexId)
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                        _context.SaveChanges();
                                    }
                                    else
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                            EndDate = DateTime.UtcNow,
                                            Comment = comment,
                                            Roe = model.Roe
                                        });
                                        _context.SaveChanges();
                                    }
                                }

                            }

                            _context.SaveChanges();

                            lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                            fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                            var fileActivityLists = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();
                            if (fileActivityLists != null)
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == sIToCarrier)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == obddn).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = obddn,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == obddn)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoice).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = invoice,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == telex)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }

                            }
                            else
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                        else
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();

                            var containersListData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                            _context.ContainerMaster.Add(new ContainerMaster
                            {
                                ContainerNo = model.ContainerNo,
                                FileId = model.FileId,
                                SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                            });
                            _context.SaveChanges();

                            var containerData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = containerData.Id,
                                ActivityId = model.ActivityId,
                                StatusId = model.StatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                Roe = model.Roe
                            });

                            _context.SaveChanges();

                            lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                            fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                            var fileActivityLists = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();
                            if (fileActivityLists != null)
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == sIToCarrier)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == obddn).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = obddn,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == obddn)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoice).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = invoice,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == telex)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }

                            }
                            else
                            {
                                if (lastActivity == invoice)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == telex).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = telex,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                    }
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
        }

        [HttpPost]
        public JsonResult AddHBLActivities(HBLActivityLogViewModel model, string button, string? statusValue, string? startDateValue, string? containerNoValue, string? endDateValue, string? hblComments, string? activityValue, string? hblNoValue, string? podValue, string? fileNoValue, string? bookingNoValue, string? customerValue, string? amsStatusValue, string? amsDatailsValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var editData = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);
            var wip = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == "WIP");
            var statusList = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Status == statusValue);
            var hblList = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId);
            var userList = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.UserName == model.UserId);
            var sIToCarrier = _context.ActivityMaster.Where(x => x.NameOfActivity == "SI To Carrier" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();

            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;

            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    var hblactivityList = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);

                    if (activityValue != null)
                    {
                        var activtyList = _context.ActivityMaster.Where(x => x.NameOfActivity == activityValue && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
                        hblactivityList = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == activtyList.Id);
                        if (hblactivityList != null && hblactivityList.Status.Status != "Completed")
                        {
                            if (editData != null && model.StatusId != wip.Status)
                            {
                                hblList.HBLId = model.HBLId;
                                hblList.ActivityId = hblactivityList.ActivityId;
                                hblList.StatusId = wip.Id;
                                hblList.UserId = userid;
                                hblList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.HBLActivityLog.Update(hblList);
                            }
                            else if (editData != null && model.StatusId == wip.Status && editData.UserId == userid)
                            {
                                hblList.HBLId = model.HBLId;
                                hblList.ActivityId = hblactivityList.ActivityId;
                                hblList.StatusId = wip.Id;
                                hblList.UserId = userid;
                                hblList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.HBLActivityLog.Update(hblList);
                            }
                            else
                            {
                                return Json("Activity is processed by other user");
                            }
                        }

                    }
                    else
                    {
                        _context.HBLActivityLog.Add(new HBLActivityLog
                        {
                            HBLId = model.HBLId,
                            ActivityId = model.ActivityId,
                            StatusId = wip.Id,
                            UserId = userid,
                            StartDate = null,
                            EndDate = null,
                            Comment = null
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");

                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    if (editData != null)
                    {
                        hblList.HBLId = model.HBLId;
                        hblList.ActivityId = model.ActivityId;
                        hblList.StatusId = selectedStatusId;
                        hblList.UserId = userId;
                        _context.HBLActivityLog.Update(hblList);
                    }
                    _context.SaveChanges();

                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else
            {
                if (ModelState.IsValid)
                {
                    //var countryList = _context.CountryMaster.FirstOrDefault(x => x.CountryName.Contains(model.POD.ToUpper().Trim()));
                    //var countryData = _context.CountryMaster.FirstOrDefault(x => x.Id == countryList.Id);

                    //if (countryList != null)
                    //{
                    //    countryList.CountryName = model.POD;
                    //    _context.CountryMaster.Update(countryList);
                    //}
                    //_context.SaveChanges();

                    var fileList = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(model.FileNo.Trim()));
                    var fileData = _context.FileMaster.FirstOrDefault(x => x.Id == fileList.Id);

                    //if (fileData != null)
                    //{
                    //    fileData.FileNumber = model.FileNo;
                    //    _context.FileMaster.Update(fileData);
                    //}
                    //_context.SaveChanges();

                     var containerList = _context.ContainerMaster.FirstOrDefault(x => (x.ContainerNo == model.ContainerNo.Trim() && x.FileId == fileData.Id) || (containerNoValue == null && x.FileId == fileData.Id));
                    
                    if (containerList != null)
                    {
                        var containerData = _context.ContainerMaster.FirstOrDefault(x => x.Id == containerList.Id);
                        containerData.ContainerNo = model.ContainerNo;
                        _context.ContainerMaster.Update(containerData);

                    }
                    else
                    {
                        _context.ContainerMaster.Add(new ContainerMaster
                        {
                            ContainerNo = model.ContainerNo,
                            FileId = fileData.Id,
                            SICutOff = DateTime.UtcNow.AddDays(10),
                        });
                        _context.SaveChanges();
                        containerList = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo.Trim() && x.FileId == fileData.Id);

                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = containerList.Id,
                            ActivityId = sIToCarrier,
                            StatusId = null,
                            UserId = userid,
                            StartDate = null,
                            EndDate = null,
                            Comment = null
                        });
                    }
                    _context.SaveChanges();

                    containerList = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo.Trim() && x.FileId == fileData.Id);

                    var hblData = _context.HBLMaster.FirstOrDefault(x => x.Id == model.HBLId);

                    if (hblData != null)
                    {
                        hblData.HBLNumber = model.HBLNumber;
                        hblData.Booking = model.BookingNo;
                        hblData.CustomerName = model.CustomerName;
                        hblData.AMSStatus = model.AMSStatus;
                        hblData.AMSDetails = model.AMSDetails;
                        hblData.ContainerId = containerList.Id;
                        _context.HBLMaster.Update(hblData);
                    }
                    _context.SaveChanges();

                    var activityListData = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);
                    if (activityListData != null)
                    {
                        _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                        {
                            HBLogId = activityListData.Id,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                            Comment = hblComments
                        });

                        var hblLog = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.Id == activityListData.Id && x.ActivityId == model.ActivityId);
                        if (hblLog != null)
                        {
                            hblLog.ActivityId = model.ActivityId;
                            hblLog.StatusId = model.StatusId;
                            hblLog.UserId = userid;
                            hblLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                            hblLog.EndDate = DateTime.UtcNow;
                            hblLog.Comment = model.Comment;
                            _context.HBLActivityLog.Update(hblLog);
                        }
                        else
                        {
                            _context.HBLActivityLog.Add(new HBLActivityLog
                            {
                                HBLId = hblList.HBLId,
                                ActivityId = model.ActivityId,
                                StatusId = model.StatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment
                            });
                        }
                    }
                    else
                    {
                        _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                        {
                            HBLogId = hblList.Id,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                            Comment = hblComments
                        });

                        var activityData = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);

                        _context.HBLActivityLog.Add(new HBLActivityLog
                        {
                            HBLId = hblList.HBLId,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }

            }
        }

        [HttpGet]
        public IActionResult CreateFile()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }
        [HttpPost]
        public IActionResult AddFileNewActivity(FileAddActivityLogModel file)
        {
            if (ModelState.IsValid)
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                FileMaster fileMaster = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(file.FileNumber.ToUpper().Trim()));
                var currentDate = DateTime.Now;
                DateTime ETD = Convert.ToDateTime(file.ETD);
                DateTime ETA = Convert.ToDateTime(file.ETA);
                DateTime ETAPOD = Convert.ToDateTime(file.ETAPOD);
                DateTime ATD = Convert.ToDateTime(file.ATD);
                var carrierRequest = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.NameOfActivity == "SI To Carrier");
                var country = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.Id == file.CountryId);
                var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
                List<string>? containerNumbers = file.ContainerNumbers;
                //var wip = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                if (role == "User")
                {
                    if (country == null)
                    {
                        country = new CountryMaster
                        {
                            CountryName = country.CountryName,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.CountryMaster.Add(country);
                    }
                    else
                    {
                        country.CountryName = country.CountryName;
                        _context.CountryMaster.Update(country);
                    }
                    _context.SaveChanges();
                    if (fileMaster == null)
                    {
                        fileMaster = new FileMaster
                        {
                            POD = file.CountryId,
                            FileNumber = file.FileNumber.ToUpper().Trim(),
                            ETD = ETD,
                            ShippingAgent = file.ShippingAgent,
                            ShippingLine = file.ShippingLine,
                            FileContact = file.FileContact,
                            TotalBL = file.TotalHBL,
                            ETA = ETA,
                            ETAPOD = ETAPOD,
                            ATD = ATD,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.FileMaster.Add(fileMaster);

                        var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id);
                        if(containerNumbers != null && containerNumbers.Count != 0)
                        {
                            foreach (var container in containerNumbers)
                            {
                                var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == container).FirstOrDefault();
                                if (containermaster != null)
                                {
                                    containermaster.FileId = fileMaster.Id;
                                    containermaster.ContainerNo = container;
                                    _context.ContainerMaster.Update(containermaster);
                                }
                                else
                                {
                                    if (fileContainer != null)
                                    {
                                        fileContainer.FileId = fileMaster.Id;
                                        fileContainer.ContainerNo = container;
                                        _context.ContainerMaster.Update(fileContainer);
                                    }
                                    else
                                    {
                                        _context.ContainerMaster.Add(new ContainerMaster
                                        {
                                            FileId = fileMaster.Id,
                                            ContainerNo = container,
                                            SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                        });
                                    }
                                    //_context.ContainerMaster.Add(new ContainerMaster
                                    //{
                                    //    FileId = fileMaster.Id,
                                    //    ContainerNo = file.Container,
                                    //    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                    //});
                                }

                                _context.SaveChanges();

                                var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == container);
                                _context.FileActivityLog.Add(new FileActivityLog
                                {
                                    ContainerId = fileLog.Id,
                                    ActivityId = carrierRequest.Id,
                                    StatusId = null,
                                    Comment = null,
                                    UserId = userid,
                                    StartDate = null,
                                    EndDate = null,
                                });
                                _context.SaveChanges();
                            }
                        }
                        else
                        {
                            var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == null).FirstOrDefault();
                            if (containermaster != null)
                            {
                                containermaster.FileId = fileMaster.Id;
                                containermaster.ContainerNo = null;
                                _context.ContainerMaster.Update(containermaster);
                            }
                            else
                            {
                                if (fileContainer != null)
                                {
                                    fileContainer.FileId = fileMaster.Id;
                                    fileContainer.ContainerNo = null;
                                    _context.ContainerMaster.Update(fileContainer);
                                }
                                else
                                {
                                    _context.ContainerMaster.Add(new ContainerMaster
                                    {
                                        FileId = fileMaster.Id,
                                        ContainerNo = null,
                                        SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                    });
                                }
                                //_context.ContainerMaster.Add(new ContainerMaster
                                //{
                                //    FileId = fileMaster.Id,
                                //    ContainerNo = file.Container,
                                //    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                //});
                            }
                            _context.SaveChanges();

                            var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == null);
                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = fileLog.Id,
                                ActivityId = carrierRequest.Id,
                                StatusId = null,
                                Comment = null,
                                UserId = userid,
                                StartDate = null,
                                EndDate = null,
                            });
                            _context.SaveChanges();
                        }
                        
                        //var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container).FirstOrDefault();
                        //if (containermaster != null)
                        //{
                        //    containermaster.FileId = fileMaster.Id;
                        //    containermaster.ContainerNo = file.Container;
                        //    _context.ContainerMaster.Update(containermaster);
                        //}
                        //else
                        //{
                        //    if (fileContainer != null)
                        //    {
                        //        fileContainer.FileId = fileMaster.Id;
                        //        fileContainer.ContainerNo = file.Container;
                        //        _context.ContainerMaster.Update(fileContainer);
                        //    }
                        //    else
                        //    {
                        //        _context.ContainerMaster.Add(new ContainerMaster
                        //        {
                        //            FileId = fileMaster.Id,
                        //            ContainerNo = file.Container,
                        //            SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                        //        });
                        //    }
                        //    //_context.ContainerMaster.Add(new ContainerMaster
                        //    //{
                        //    //    FileId = fileMaster.Id,
                        //    //    ContainerNo = file.Container,
                        //    //    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                        //    //});
                        //}

                        //_context.SaveChanges();

                       
                    }
                    else
                    {
                        return Json("Duplicate");
                    }

                    if (file.FileActivities != null)
                    {
                        foreach (FileActivityLogItem log in file.FileActivities)
                        {
                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = fileMaster.Id,
                                ActivityId = log.ActivityId,
                                StatusId = log.StatusId,
                                Comment = log.Comment,
                                UserId = null,
                                StartDate = Convert.ToDateTime(file.StartDateTime).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                            });
                        }
                    }

                    _context.SaveChanges();

                    return Json("Success");
                }
                else
                {
                    if (fileMaster == null)
                    {
                        //wip = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        if (country == null)
                        {
                            country = new CountryMaster
                            {
                                CountryName = country.CountryName,
                                IsActive = true,
                                IsDelete = false
                            };
                            _context.CountryMaster.Add(country);
                        }
                        else
                        {
                            country.CountryName = country.CountryName;
                            _context.CountryMaster.Update(country);
                        }
                        _context.SaveChanges();
                        fileMaster = new FileMaster
                        {
                            POD = file.CountryId,
                            FileNumber = file.FileNumber.ToUpper().Trim(),
                            ETD = ETD,
                            ShippingAgent = file.ShippingAgent,
                            ShippingLine = file.ShippingLine,
                            FileContact = file.FileContact,
                            TotalBL = file.TotalHBL,
                            ETA = ETA,
                            ETAPOD = ETAPOD,
                            ATD = ATD,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.FileMaster.Add(fileMaster);

                        var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id);
                        
                        if(containerNumbers != null && containerNumbers.Count != 0)
                        {
                            foreach (var container in containerNumbers)
                            {
                                var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == container).FirstOrDefault();
                                if (containermaster != null)
                                {
                                    containermaster.FileId = fileMaster.Id;
                                    containermaster.ContainerNo = container;
                                    _context.ContainerMaster.Update(containermaster);
                                }
                                else
                                {
                                    if (fileContainer != null)
                                    {
                                        fileContainer.FileId = fileMaster.Id;
                                        fileContainer.ContainerNo = container;
                                        _context.ContainerMaster.Update(fileContainer);
                                    }
                                    else
                                    {
                                        _context.ContainerMaster.Add(new ContainerMaster
                                        {
                                            FileId = fileMaster.Id,
                                            ContainerNo = container,
                                            SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                        });
                                    }
                                    //_context.ContainerMaster.Add(new ContainerMaster
                                    //{
                                    //    FileId = fileMaster.Id,
                                    //    ContainerNo = file.Container,
                                    //    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                    //});
                                }

                                _context.SaveChanges();

                                var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == container);
                                _context.FileActivityLog.Add(new FileActivityLog
                                {
                                    ContainerId = fileLog.Id,
                                    ActivityId = carrierRequest.Id,
                                    StatusId = null,
                                    Comment = null,
                                    UserId = userid,
                                    StartDate = null,
                                    EndDate = null,
                                });
                                _context.SaveChanges();
                            }
                        }
                        else
                        {
                            var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == null).FirstOrDefault();
                            if (containermaster != null)
                            {
                                containermaster.FileId = fileMaster.Id;
                                containermaster.ContainerNo = null;
                                _context.ContainerMaster.Update(containermaster);
                            }
                            else
                            {
                                if (fileContainer != null)
                                {
                                    fileContainer.FileId = fileMaster.Id;
                                    fileContainer.ContainerNo = null;
                                    _context.ContainerMaster.Update(fileContainer);
                                }
                                else
                                {
                                    _context.ContainerMaster.Add(new ContainerMaster
                                    {
                                        FileId = fileMaster.Id,
                                        ContainerNo = null,
                                        SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                    });
                                }
                                //_context.ContainerMaster.Add(new ContainerMaster
                                //{
                                //    FileId = fileMaster.Id,
                                //    ContainerNo = file.Container,
                                //    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                //});
                            }

                            _context.SaveChanges();

                            var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == null);
                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = fileLog.Id,
                                ActivityId = carrierRequest.Id,
                                StatusId = null,
                                Comment = null,
                                UserId = userid,
                                StartDate = null,
                                EndDate = null,
                            });
                            _context.SaveChanges();
                        }
                        
                    }
                    else
                    {
                        return Json("Duplicate");
                    }

                    if (file.FileActivities != null)
                    {
                        foreach (FileActivityLogItem log in file.FileActivities)
                        {
                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = fileMaster.Id,
                                ActivityId = log.ActivityId,
                                StatusId = log.StatusId,
                                Comment = log.Comment,
                                UserId = null,
                                StartDate = Convert.ToDateTime(file.StartDateTime).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                            });
                        }
                    }

                    _context.SaveChanges();

                    return Json("Success");
                }
            }
            else
            {
                return Json("Error while processing the request");
            }


        }


        [HttpGet]
        public IActionResult CreateHBL()
        {
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return PartialView();
        }


        //[HttpPost]
        //public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        //{
        //    string Msg = "";
        //    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "SI To Carrier");
        //    List<string> hblNumbers = hbl.HBLNumbers;
        //    List<HBLMaster> hblMaster = new List<HBLMaster>();
        //    HBLMaster  hblMasters = new HBLMaster();

        //    if (ModelState.IsValid)
        //    {
        //        var file = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(hbl.FileNo.ToUpper().Trim()));

        //        if (file == null)
        //        {
        //            Msg = "File does not exist. First insert the file.";
        //        }
        //        else
        //        {
        //            foreach (var hblNumber in hblNumbers)
        //            {
        //                // Perform actions with each HBL number, e.g., save to a database
        //                hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
        //                hblMaster.Add(hblMasters);
        //            }
        //            if (hblMaster == null)
        //            {
        //                var container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == hbl.Container);
        //                var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id);
        //                if (container == null)
        //                {
        //                    if (fileContainer.ContainerNo == null || fileContainer.ContainerNo == "")
        //                    {
        //                        fileContainer.FileId = file.Id;
        //                        fileContainer.ContainerNo = hbl.Container;
        //                        _context.ContainerMaster.Update(fileContainer);
        //                    }
        //                    else
        //                    {
        //                        _context.ContainerMaster.Add(new ContainerMaster
        //                        {
        //                            FileId = file.Id,
        //                            ContainerNo = hbl.Container
        //                        });
        //                    }


        //                }
        //                else
        //                {
        //                    container.FileId = file.Id;
        //                    container.ContainerNo = hbl.Container;
        //                    _context.ContainerMaster.Update(container);
        //                }
        //                _context.SaveChanges();

        //                container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == hbl.Container);

        //                var fileLog = _context.FileActivityLog.FirstOrDefault(x => x.ContainerId == container.Id);

        //                if (fileLog == null)
        //                {
        //                    _context.FileActivityLog.Add(new FileActivityLog
        //                    {
        //                        ContainerId = container.Id,
        //                        ActivityId = carrierRequest.Id,
        //                        StatusId = null,
        //                        Comment = null,
        //                        UserId = null,
        //                        StartDate = null,
        //                        EndDate = null
        //                    });
        //                }
        //                else
        //                {
        //                    fileLog.ContainerId = container.Id;
        //                    fileLog.ActivityId = fileLog.ActivityId;
        //                    fileLog.StatusId = fileLog.StatusId;
        //                    fileLog.Comment = fileLog.Comment;
        //                    fileLog.UserId = userid;
        //                    fileLog.StartDate = fileLog.StartDate;
        //                    fileLog.EndDate = fileLog.EndDate;
        //                    _context.FileActivityLog.Update(fileLog);
        //                }

        //                if (hblMaster == null)
        //                {
        //                    foreach (var hblNumber in hblNumbers)
        //                    {
        //                        // Perform actions with each HBL number, e.g., save to a database
        //                        hblMasters = new HBLMaster
        //                        {
        //                            Id = hbl.Id,
        //                            HBLNumber = hblNumber,
        //                            ContainerId = container.Id,
        //                            Booking = hbl.BookingNo,
        //                            CustomerName = hbl.CustomerName,
        //                            EnterDate = DateTime.UtcNow,
        //                            IsActive = true,
        //                            IsDelete = false
        //                        };
        //                        _context.HBLMaster.Add(hblMasters);
        //                    }
        //                    //hblMasters = new HBLMaster
        //                    //{
        //                    //    Id = hbl.Id,
        //                    //    HBLNumber = hbl.HBL_No,
        //                    //    ContainerId = container.Id,
        //                    //    Booking = hbl.BookingNo,
        //                    //    CustomerName = hbl.CustomerName,
        //                    //    EnterDate = DateTime.UtcNow,
        //                    //    IsActive = true,
        //                    //    IsDelete = false
        //                    //};

        //                    //_context.HBLMaster.Add(hblMaster);
        //                    _context.SaveChanges();
        //                    var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
        //                    if (role == "User")
        //                    {
        //                        foreach (var hblNumber in hblNumbers)
        //                        {
        //                            var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
        //                            HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

        //                            hBLActivityLog = new HBLActivityLog
        //                            {
        //                                HBLId = hbllist.Id,
        //                                ActivityId = hbl.HBLActivities[0].ActivityId,
        //                                StatusId = hbl.HBLActivities[0].StatusId,
        //                                UserId = userid,
        //                                Comment = hbl.HBLActivities[0].Comment,
        //                                StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
        //                                EndDate = DateTime.UtcNow
        //                            };
        //                            _context.HBLActivityLog.Add(hBLActivityLog);
        //                            _context.SaveChanges();
        //                            Msg = "HBL Inserted Successfully..!!";
        //                        }

        //                    }
        //                    else
        //                    {
        //                        foreach (var hblNumber in hblNumbers)
        //                        {
        //                            var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
        //                            HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

        //                            hBLActivityLog = new HBLActivityLog
        //                            {
        //                                HBLId = hbllist.Id,
        //                                ActivityId = hbl.HBLActivities[0].ActivityId,
        //                                StatusId = hbl.HBLActivities[0].StatusId,
        //                                UserId = null,
        //                                Comment = hbl.HBLActivities[0].Comment,
        //                                StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
        //                                EndDate = DateTime.UtcNow
        //                            };
        //                            _context.HBLActivityLog.Add(hBLActivityLog);
        //                            _context.SaveChanges();
        //                            Msg = "HBL Inserted Successfully..!!";
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    Msg = "HBL number is already added";
        //                }
        //                return Json(Msg);
        //            }
        //            else
        //            {
        //                Msg = "Duplicate HBL numbers are: " + string.Join(", ", hblMaster.Select(h => h.HBLNumber));
        //                return Json(Msg);
        //            }

        //        }
        //    }
        //    else
        //    {
        //        return Json("Error while processing the request");
        //    }
        //}

        [HttpPost]
        public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        {
            string Msg = "";
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var carrierRequest = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.NameOfActivity == "SI To Carrier");
            List<string> hblNumbers = hbl.HBLNumbers;
            List<string> bookingNumbers = hbl.BookingNumbers;
            List<string> customerNames = hbl.CustomerNames;
            //List<string> customerNames = hbl.CustomerNames;
            List<HBLMaster> hblMaster = new List<HBLMaster>();
            HBLMaster hblMasters = new HBLMaster();

            if (ModelState.IsValid)
            {
                var file = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(hbl.FileNo.ToUpper().Trim()));

                if (file == null)
                {
                    Msg = "File does not exist. First insert the file.";
                }
                else
                {
                    if (hblNumbers.Count != bookingNumbers.Count)
                    {
                        Msg = "The count of HBL numbers and Booking numbers should be the same.";
                    }
                    //else if (bookingNumbers.Count != customerNames.Count)
                    //{
                    //    Msg = "The count of Custome Names and Booking numbers should be the same.";
                    //}
                    else
                    {
                        foreach (var hblNumber in hblNumbers)
                        {
                            // Check if the HBL number already exists in the database
                            hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                            if (hblMasters != null)
                            {
                                hblMaster.Add(hblMasters);
                            }
                        }

                        if (hblMaster.Count == 0)
                        {
                            var conatinerNo = "";
                            if (hbl.Container != null)
                            {
                                conatinerNo = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && (x.ContainerNo == hbl.Container || x.Id == hbl.Container))?.ContainerNo;
                            }
                            var container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == conatinerNo);
                            var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id);

                            if (container == null)
                            {
                                if (fileContainer.ContainerNo == null || fileContainer.ContainerNo == "")
                                {
                                    fileContainer.FileId = file.Id;
                                    fileContainer.ContainerNo = hbl.Container;
                                    _context.ContainerMaster.Update(fileContainer);
                                }
                                else
                                {
                                    _context.ContainerMaster.Add(new ContainerMaster
                                    {
                                        FileId = file.Id,
                                        ContainerNo = hbl.Container
                                    });
                                }
                            }
                            else
                            {
                                container.FileId = file.Id;
                                container.ContainerNo = hbl.Container;
                                _context.ContainerMaster.Update(container);
                            }
                            _context.SaveChanges();

                            container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == hbl.Container);

                            var fileLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.ContainerId == container.Id);

                            if (fileLog == null)
                            {
                                _context.FileActivityLog.Add(new FileActivityLog
                                {
                                    ContainerId = container.Id,
                                    ActivityId = carrierRequest.Id,
                                    StatusId = null,
                                    Comment = null,
                                    UserId = userid,
                                    StartDate = null,
                                    EndDate = null
                                });
                            }
                            else
                            {
                                fileLog.ContainerId = container.Id;
                                fileLog.ActivityId = fileLog.ActivityId;
                                fileLog.StatusId = fileLog.StatusId;
                                fileLog.Comment = fileLog.Comment;
                                fileLog.UserId = userid;
                                fileLog.StartDate = fileLog.StartDate;
                                fileLog.EndDate = fileLog.EndDate;
                                _context.FileActivityLog.Update(fileLog);
                            }

                            for (int i = 0; i < hblNumbers.Count; i++)
                            {
                                var hblNumber = hblNumbers[i];
                                var bookingNumber = bookingNumbers[i];
                                var customerName = customerNames[i];
                                // Check if the HBL number already exists in the database
                                hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                                if (hblMasters == null)
                                {
                                    // Perform actions with each HBL number, e.g., save to a database
                                    hblMasters = new HBLMaster
                                    {
                                        //Id = hbl.Id,
                                        HBLNumber = hblNumber,
                                        ContainerId = container.Id,
                                        Booking = bookingNumber,
                                        CustomerName = customerName,
                                        AMSStatus = null,
                                        AMSDetails = null,
                                        EnterDate = DateTime.UtcNow,
                                        IsActive = true,
                                        IsDelete = false
                                    };
                                    _context.HBLMaster.Add(hblMasters);
                                    _context.SaveChanges();
                                }

                                var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
                                if (role == "User")
                                {
                                    var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                                    HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

                                    hBLActivityLog = new HBLActivityLog
                                    {
                                        HBLId = hbllist.Id,
                                        ActivityId = hbl.HBLActivities[0].ActivityId,
                                        StatusId = hbl.HBLActivities[0].StatusId,
                                        UserId = userid,
                                        Comment = hbl.HBLActivities[0].Comment,
                                        StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
                                        EndDate = DateTime.UtcNow
                                    };
                                    _context.HBLActivityLog.Add(hBLActivityLog);
                                    _context.SaveChanges();

                                    Msg = "HBL Inserted Successfully..!!";
                                }
                                else
                                {

                                    var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                                    HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

                                    hBLActivityLog = new HBLActivityLog
                                    {
                                        HBLId = hbllist.Id,
                                        ActivityId = hbl.HBLActivities[0].ActivityId,
                                        StatusId = hbl.HBLActivities[0].StatusId,
                                        UserId = userid,
                                        Comment = hbl.HBLActivities[0].Comment,
                                        StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
                                        EndDate = DateTime.UtcNow
                                    };
                                    _context.HBLActivityLog.Add(hBLActivityLog);
                                    _context.SaveChanges();
                                }
                                Msg = "HBL Inserted Successfully..!!";
                            }
                        }
                        else
                        {
                            //Msg = "Duplicate HBL numbers are: " + string.Join(", ", hblMaster.Select(h => h.HBLNumber));
                            //"Duplicate HBL numbers are: " + string.Join(", ", duplicateHBLs) +
                            //"\nDuplicate booking numbers are: " + string.Join(", ", duplicateBookings);
                            //var table = "<table><tr><th>Bookings</th><th>HBL</th></tr>";
                            //for (int i = 0; i < hblMaster.Count; i++)
                            //{
                            //    table += "<tr><td>" + hblMaster[i].Booking + "</td><td>" + hblMaster[i].HBLNumber + "</td></tr>";
                            //}
                            //table += "</table>";
                            var table = "<div class='box'><div class='box-header with-border'><h3 class='box-title' style='font-weight: bold; color:black; background-color: #ffc107; font-size: 14px;'>Duplicate Booking and HBL Numbers</h3></div><div class='box-body'><table class='table table-bordered'><thead><tr><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>Bookings</th><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>HBL</th></tr></thead><tbody>";

                            for (int i = 0; i < hblMaster.Count; i++)
                            {
                                table += "<tr style='color:black; padding:0.2rem;'><td style='color:black; padding:0.2rem;'>" + hblMaster[i].Booking + "</td><td style='color:black; padding:0.2rem;'>" + hblMaster[i].HBLNumber + "</td></tr>";
                            }

                            table += "</tbody></table></div></div>";
                            Msg = table; // Return the entire table HTML

                            //Msg = "Duplicate Booking and HBL numbers:<br>" + table;
                            //return Content(Msg, "text/html");
                            return Json(Msg);
                        }
                    }
                }
            }
            else
            {
                Msg = "Error while processing the request";
            }

            return Json(Msg);
        }


        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            //ViewData["Container"] = _context.ContainerMaster.OrderBy(x => x.FileMaster.EnterDate).ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult InsertNewFile(FileInsertModel file)
        {
            if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(file.FileNumber.ToUpper().Trim()));

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        POD = file.CountryId,
                        FileNumber = file.FileNumber,
                        ETD = Convert.ToDateTime(file.ETD).ToUniversalTime(),
                        ShippingAgent = file.ShippingAgent,
                        ShippingLine = file.ShippingLine,
                        FileContact = file.FileContact,
                        TotalBL = file.TotalHBL,
                        ETA = Convert.ToDateTime(file.ETA).ToUniversalTime(),
                        ETAPOD = Convert.ToDateTime(file.ETAPOD).ToUniversalTime(),
                        ATD = Convert.ToDateTime(file.ATD).ToUniversalTime(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }
                else
                {
                    fileMaster.POD = file.CountryId;
                    fileMaster.FileNumber = file.FileNumber;
                    fileMaster.ETD = Convert.ToDateTime(file.ETD).ToUniversalTime();
                    fileMaster.ShippingAgent = file.ShippingAgent;
                    fileMaster.ShippingLine = file.ShippingLine;
                    fileMaster.FileContact = file.FileContact;
                    fileMaster.TotalBL = file.TotalHBL;
                    fileMaster.ETA = Convert.ToDateTime(file.ETA).ToUniversalTime();
                    fileMaster.ETAPOD = Convert.ToDateTime(file.ETAPOD).ToUniversalTime();
                    fileMaster.ATD = Convert.ToDateTime(file.ATD).ToUniversalTime();
                    fileMaster.EnterDate = DateTime.UtcNow;
                    fileMaster.IsActive = true;
                    fileMaster.IsDelete = false;

                    _context.FileMaster.Update(fileMaster);
                }

                var container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container);

                if (container == null)
                {
                    _context.ContainerMaster.Add(new ContainerMaster
                    {
                        FileId = fileMaster.Id,
                        ContainerNo = file.Container,
                        SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime()
                    });
                }
                else
                {
                    container.FileId = fileMaster.Id;
                    container.ContainerNo = file.Container;
                    container.SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime();

                    _context.ContainerMaster.Update(container);
                }

                _context.SaveChanges();

                return Json("Success");
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        public ActionResult GetContainers(string fileNumber)
        {
            var containers = new List<ContainerMaster>();
            var fileId = _context.FileMaster.Where(x => x.FileNumber == fileNumber).Select(x => x.Id).FirstOrDefault();
            var containerList = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();
            var response = new
            {
                containers = containerList
            };

            return Json(containerList);
        }


        public IActionResult FileQuery(string activityId)
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetFilesQuery(string country, string fileNumber, string activity, string search, string type, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var filesData = _context.FileActivityLog
                .Include(x => x.ContainerMaster)
                    .ThenInclude(x => x.FileMaster)
                        .ThenInclude(x => x.CountryMaster)
                .Include(x => x.Activity)
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Select(x => new FileDashModel
                {
                    Id = x.Id,
                    POD = x.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    EnterDate = x.ContainerMaster.FileMaster.EnterDate,
                    FileNumber = x.ContainerMaster.FileMaster.FileNumber,
                    ContainerNo = x.ContainerMaster.ContainerNo,
                    ETD = x.ContainerMaster.FileMaster.ETD,
                    SICutOff = x.ContainerMaster.SICutOff,
                    ActivityId = x.Activity.NameOfActivity,
                    ActivityType = x.Activity.ActivityType,
                    UserId = role != "User" ? x.ApplicationUser.UserName : x.ApplicationUser.UserName,
                    StatusId = x.Status.Status,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentUser = userid,
                    Role = role
                }).AsQueryable();
            IQueryable<FileDashModel> data = filesData.AsQueryable();
            DateTime date = DateTime.UtcNow;
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= date.Date || x.SICutOff.Value.Date == null);
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                data = data.Where(x => x.StatusId == status);
            }
            else
            {
                data = data.Where(x => x.StatusId != "Completed");
            }

            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                data = data.Where(x => x.ActivityId == activity);
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }

            var files = data
                .Where(x => x.StatusId != "Completed" && x.StatusId != "WIP" && x.StatusId != null)
                .OrderBy(sortColumn + " " + sortColumnDirection)
                .Skip(skip)
                .Take(pageSize)
                .ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = filesData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetfileData(string fileNumber)
        {
            var hbl = _context.HBLMaster.Where(x => x.ContainerMaster.FileMaster.FileNumber == fileNumber).ToList();
            var file = _context.FileMaster.Where(x => x.FileNumber == fileNumber).Select(x => new { x.Id }).FirstOrDefault();
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster.FileMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == file.Id).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();

            return Json(new { fm, hbl, sm });
        }

        public IActionResult HBLQuery(string activityId, string fileNumber)
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetHBLQuery(string country, string hblNumber, string activity, string search, string type)
        {
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            // Create a base query
            var data = _context.HBLActivityLog
                .Include(x => x.Hbl)
                .Include(x => x.Hbl.ContainerMaster.FileMaster.CountryMaster)
                .Include(x => x.Activity)
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    POD = x.Hbl.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                    BookingNo = x.Hbl.Booking,
                    HBLNumber = x.Hbl.HBLNumber,
                    Activity = x.Activity.NameOfActivity,
                    ActivityType = x.Activity.ActivityType,
                    User = x.ApplicationUser.UserName,
                    Status = x.Status.Status,
                    StatusId = x.StatusId,
                    Comment = x.Comment,
                    CurrentUser = userId,
                    Role = role
                }).AsQueryable();
            IQueryable<HBLDashViewModel> baseQuery = data.AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(hblNumber))
            {
                baseQuery = baseQuery.Where(x => x.FileNumber.Contains(hblNumber.Trim()));
            }
            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                baseQuery = baseQuery.Where(x => x.POD == country);
            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                baseQuery = baseQuery.Where(x => x.Activity == activity);
            }

            // Apply sorting
            if (string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "hblNumber";
            }
            baseQuery = baseQuery.OrderBy(sortColumn + " " + sortColumnDirection);

            // Count total records without pagination
            int totalRecords = baseQuery.Count();

            // Apply pagination and get the data
            var files = baseQuery
                .Where(x => x.Status != "Completed" && x.Status != "WIP" /*&& (role != "User" || x.User == userId)*/)
                .Skip(skip)
                .Take(pageSize)
                .ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = data.Count(),
                recordsFiltered = files.Count(),
                data = files
            });


            // Return the data in the format required by DataTables

        }

        [HttpGet]
        public IActionResult GetHBLActivityQuery(string Id)
        {
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().Where(x => x.Status == "Query").AsQueryable();


            return Json(new { HBL, sm, Id });
        }

        public IActionResult HBLActivityChangeStatus(string id, string status, string comment, string startDate)
        {
            var hblActivity = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Id == id).FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var hblActivityLog = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Id == id && x.ActivityId == hblActivity.ActivityId).FirstOrDefault();

            _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
            {
                HBLogId = hblActivity.Id,
                ActivityId = hblActivity.ActivityId,
                StatusId = hblActivity.StatusId,
                Comment = hblActivity.Comment,
                UserId = hblActivity.UserId,
                StartDate = hblActivity.StartDate,
                EndDate = hblActivity.EndDate,
            });
            _context.SaveChanges();

            if (hblActivity != null)
            {
                hblActivityLog.StatusId = status;
                hblActivityLog.Comment = comment;
                hblActivityLog.UserId = userid;
                hblActivityLog.StartDate = Convert.ToDateTime(startDate).ToUniversalTime();
                hblActivityLog.EndDate = DateTime.UtcNow;
                _context.HBLActivityLog.Update(hblActivityLog);
                _context.SaveChanges();
            }
            else
            {
                return Json("Error while processing the request.");
            }

            return Json("success");
        }

        public IActionResult FileActivityChangeStatus(string id, string status, string comment, string startDate)
        {
            var fileActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Id == id).FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivityLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Id == id && x.ActivityId == fileActivity.ActivityId).FirstOrDefault();

            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
            {
                FileLogId = fileActivity.Id,
                ActivityId = fileActivity.ActivityId,
                StatusId = fileActivity.StatusId,
                Comment = fileActivity.Comment,
                UserId = fileActivity.UserId,
                StartDate = fileActivity.StartDate,
                EndDate = fileActivity.EndDate,

            });
            _context.SaveChanges();

            if (fileActivity != null)
            {
                fileActivityLog.StatusId = status;
                fileActivityLog.Comment = comment;
                fileActivityLog.UserId = userid;
                fileActivityLog.StartDate = Convert.ToDateTime(startDate).ToUniversalTime();
                fileActivityLog.EndDate = DateTime.UtcNow;
                _context.FileActivityLog.Update(fileActivityLog);
                _context.SaveChanges();
            }
            else
            {
                return Json("Error while processing the request.");
            }

            return Json("success");
        }
        public IActionResult UserThread()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var activityFile = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            var activityHbl = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false && (x.NameOfActivity == "HBL Processing" || x.NameOfActivity == "BL Request")).ToList();
            var activity = activityFile.Concat(activityHbl).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            foreach (var item in activity)
            {
                if (item.ActivityType == "File")
                {
                    item.NameOfActivity += " (F)";
                }
                else
                {
                    item.NameOfActivity += " (H)";
                }

            }
            ViewData["Activity"] = activity;
            return View();
        }

        [HttpGet]
        public IActionResult GetHblData(string id)
        {

            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            //var hbl = _context.HBLMaster.Where(x => x.ContainerId == id).ToList();

            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var fms = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == id).ToList();
            var fm = fms.Select(x => new FileDashModel
            {
                ContainerId = x.ContainerMaster.ContainerNo,
                ActivityId = x.Activity.NameOfActivity,
                StatusId = x.StatusId == null ? "" : x.Status.Status,
                UserId = x.UserId == null ? "" : x.ApplicationUser.UserName,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                Comment = x.Comment == null ? "" : x.Comment,
                LBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("HKG")).Count(),
                TBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("HKG")).Count(),
                TotalHBL = (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("HKG")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("HKG")).Count())
            }).ToList();

            fm = fm.Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.ActivityId,
                StatusId = x.StatusId == null ? "" : x.StatusId,
                UserId = x.UserId == null ? "" : x.UserId,
                Comment = x.Comment == null ? "" : x.Comment,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                LBL = x.LBL,
                TBL = x.TBL,
                TotalHBL = x.TotalHBL
            }).ToList();

            var hblIdList = _context.HBLMaster.Where(x => x.ContainerId == id).Select(x => x.Id).ToList();
            var hbl = new List<HBLDashViewModel>();

            foreach (var hblId in hblIdList)
            {
                var hblActivityLogRecords = _context.HBLActivityLog
                    .Include(x => x.Hbl)
                    .Include(x => x.Hbl.ContainerMaster)
                    .Include(x => x.Activity)
                    .Include(x => x.Status)
                    .Include(x => x.ApplicationUser)
                    .Where(x => x.HBLId == hblId)
                    .Select(x => new HBLDashViewModel
                    {
                        Id = x.HBLId,
                        ContainerNo = x.Hbl.ContainerMaster.ContainerNo,
                        FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                        HBLNumber = x.Hbl.HBLNumber,
                        CustomerName = x.Hbl.CustomerName == null ? "" : x.Hbl.CustomerName,
                        BookingNo = x.Hbl.Booking,
                        Activity = x.Activity.NameOfActivity,
                        Status = x.Status.Status,
                        Comment = x.Comment == null ? "" : x.Comment,
                        User = x.ApplicationUser.UserName == null ? "" : x.ApplicationUser.UserName,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                    }).ToList();

                hblActivityLogRecords = hblActivityLogRecords.Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    ContainerNo = x.ContainerNo,
                    FileNumber = x.FileNumber,
                    HBLNumber = x.HBLNumber,
                    CustomerName = x.CustomerName,
                    BookingNo = x.BookingNo,
                    Activity = x.Activity,
                    Status = x.Status,
                    Comment = x.Comment == null ? "" : x.Comment,
                    User = x.User,
                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                }).ToList();

                hbl.AddRange(hblActivityLogRecords);
            }
            fm = fm.OrderByDescending(x => x.ActivityId).ToList();
            hbl = hbl.OrderByDescending(x => x.Activity).ToList();
            return Json(new { fm, hbl, sm });
        }

        public async Task<IActionResult> UserDashboard(string activityId)
        {
            /*ViewBag.StatusMaster */ViewData["StatusMaster"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityMaster"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            //ViewBag.Countries = _context.CountryMaster.ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.Id == activityId && x.IsDelete == false && x.IsActive == true).ToList();
            return View();
        }

        [Authorize(Roles = "User")]
        [HttpPost]
        public IActionResult GetUserDashboard(string activity, string Country, string fileNumber, string search, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            List<FileDashModel> fileDashModel = new List<FileDashModel>();

            var fileData = _context.ContainerMaster
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(x => new FileDashModel
                {
                    Id = x.FileMaster.Id,
                    FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                    EnterDate = x.FileMaster.EnterDate,
                    FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                    POD = x.FileMaster.CountryMaster.CountryName,
                    ETD = x.FileMaster.ETD,
                    ETAPOD = x.FileMaster.ETAPOD,
                    ETA = x.FileMaster.ETA,
                    ATD = x.FileMaster.ATD,
                    SICutOff = x.SICutOff,
                    ShippingLine = x.FileMaster.ShippingLine,
                    FileContact = x.FileMaster.FileContact,
                    UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                    ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = x.ContainerNo,
                    ContainerId = x.Id,
                    Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                    Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
                    SIToCarrier = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIToCarrierCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().EndDate,
                    OBDDN = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Status.Status ?? "UnAllocated",
                    OBDDNCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().EndDate,
                    Telex = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "COB").FirstOrDefault().Status.Status ?? "UnAllocated",
                    TelexCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "COB").FirstOrDefault().EndDate,
                    Invoice = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "AMS Filing").FirstOrDefault().Status.Status ?? "UnAllocated",
                    InvoiceCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "AMS Filing").FirstOrDefault().EndDate,
                    PreAlert = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().Status.Status ?? "UnAllocated",
                    PreAlertCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().EndDate,

                    LBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("HKG")).Count(),
                    TBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("HKG")).Count(),
                    TotalHBL = x.HBLMasters.Where(y => y.ContainerId == x.Id).Count() != 0 ? (x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("HKG")).Count()) + (x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("HKG")).Count()) : x.FileMaster.TotalBL

                }).AsQueryable();


            IQueryable<FileDashModel> SortedData = fileData.AsQueryable();
            DateTime date = DateTime.UtcNow;
            if (date != null)
            {
                SortedData = SortedData.Where(x => x.SICutOff.Value.Date >= date.Date || x.SICutOff.Value.Date == null);
            }
            if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                search == "Received" || search == "UnAllocated" || search == "etd10" || search == "etd12" || search == "etd18" || search == "si")
            {
                if (search == "etd10")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) <= DateTime.Now && (x.StatusId != "Completed"));
                }
                else if (search == "etd12")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.ETD).AddDays(-12) <= DateTime.Now && x.StatusId != "Completed");
                }
                else if (search == "etd18")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-12) > DateTime.Now && x.StatusId != "Completed");
                }
                else if (search == "Received")
                {
                    SortedData = SortedData;
                }
                else if (search == "UnAllocated")
                {
                    SortedData = SortedData.Where(x => x.StatusId == "UnAllocated");
                }
                else if (search == "si")
                {
                    SortedData = SortedData.Where(x => x.StatusId != "Completed" && x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today.Date && x.UserId == userName);
                }
                else
                {
                    SortedData = SortedData.Where(x => x.StatusId == search && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            SortedData = SortedData.Select(x => new FileDashModel
            {
                Id = x.Id,
                FileLogId = x.FileLogId,
                EnterDate = x.EnterDate,
                FileNumber = x.FileNumber,
                POD = x.POD,
                ETD = x.ETD,
                ETAPOD = x.ETAPOD,
                ETA = x.ETA,
                ATD = x.ATD,
                SICutOff = x.SICutOff,
                ShippingLine = x.ShippingLine,
                FileContact = x.FileContact,
                UserId = x.UserId,
                StatusId = x.StatusId,
                ActivityId = x.ActivityId,
                ActivityType = x.ActivityType,
                ContainerNo = x.ContainerNo,
                ContainerId = x.ContainerId,
                Comment = x.Comment,
                Roe = x.Roe,
                CurrentUser = x.CurrentUser,
                EndDate = x.EndDate,
                OBDDN = x.OBDDN,
                OBDDNCompleted = x.OBDDNCompleted,
                Telex = x.Telex,
                TelexCompleted = x.TelexCompleted,
                SIToCarrier = x.SIToCarrier,
                SIToCarrierCompleted = x.SIToCarrierCompleted,
                Invoice = x.Invoice,
                InvoiceCompleted = x.InvoiceCompleted,
                PreAlert = x.PreAlert,
                PreAlertCompleted = x.PreAlertCompleted,
                LBL = x.LBL,
                TBL = x.TBL,
                TotalHBL = x.TotalHBL
            }).AsQueryable();

            SortedData = SortedData.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize);

            var returnObj = new
            {
                draw = draw,
                recordsTotal = fileData.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData.ToList(),
            };

            return Json(returnObj);
        }

        public JsonResult GetDashboardCount(string? activity)
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            //var fileActivityLogs = _context.FileActivityLog
            //    .Include(x => x.ContainerMaster)
            //    .Include(x => x.Status)
            //    .Include(x => x.ApplicationUser)
            //    .ToList();

            var data = _context.ContainerMaster
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(x => new FileDashModel
                {
                    Id = x.FileMaster.Id,
                    FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                    EnterDate = x.FileMaster.EnterDate,
                    FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                    POD = x.FileMaster.CountryMaster.CountryName,
                    ETD = x.FileMaster.ETD,
                    ETAPOD = x.FileMaster.ETAPOD,
                    ETA = x.FileMaster.ETA,
                    ATD = x.FileMaster.ATD,
                    SICutOff = x.SICutOff,
                    ShippingLine = x.FileMaster.ShippingLine,
                    FileContact = x.FileMaster.FileContact,
                    UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                    ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = x.ContainerNo,
                    ContainerId = x.Id,
                    Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                    Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
                    //TallySheetId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //MblReviewId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //TblProcessingId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //TallySheetComment = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Comment ?? "",
                    //MblReviewComment = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Comment ?? "",
                    //TblProcessingComment = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Comment ?? "",
                    //CarrierRequest = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Carrier Request")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //BlRequestId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "BL Request")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "BL Request")
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //BlRequestCompleted = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "BL Request")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "BL Request")
                    //.FirstOrDefault().EndDate,
                    //TBLProcessing = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "TBL Processing")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "TBL Processing")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //TallySheetChecking = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Tally Sheet")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Tally Sheet")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //SIToCarrier = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "SI To Carrier")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "SI To Carrier")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //MBLReview = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "MBL Review")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "MBL Review")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //Invoice = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //FinalBL = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //PreAlert = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Pre-Alert")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Pre-Alert")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //Permit = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Permit")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Permit")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //LBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                    //TBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                    //TotalHBL = x.HBLMasters.Where(y => y.ContainerId == x.Id).Count() != 0 ? (x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : x.FileMaster.TotalBL

                }).AsQueryable();
            DateTime date = DateTime.UtcNow;
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= date.Date || x.SICutOff.Value.Date == null);
            }
            DashboardProdcount dp = new DashboardProdcount
            {
                Received = data.ToList().Count,
                Pending = data.Count(x => x.StatusId == "Pending" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                WIP = data.Count(x => x.StatusId == "WIP" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                Query = data.Count(x => x.StatusId == "Query" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                Completed = data.Count(x => x.StatusId == "Completed" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                UnAllocated = data.Count(x => x.StatusId == "UnAllocated"),
                siCutOff = data.Count(x => x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today.Date && x.UserId == userName && x.StatusId != "Completed"),
            };

            return Json(dp);
        }

        [HttpGet]
        public IActionResult GetContainer(string? fileNo)
        {
            var fileId = _context.FileMaster.Where(x => x.FileNumber == fileNo).Select(x => x.Id).FirstOrDefault();
            var containerList = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();
            //ViewData["Container"] = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();

            return Json(new { success = "Success", containerList });
        }




        public IActionResult Adhoc()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult AdhocFileActivity()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Adhoc" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }


        [HttpPost]
        public IActionResult AdhocFileActivity(AdhocFileActivityModel adhocfileActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocFile adhocfile = _context.AdhocFile.Where(x => x.AdhocFileNumber == adhocfileActivity.AdhocFileNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhocfile == null)
                {
                    adhocfile = new AdhocFile
                    {
                        Id = adhocfileActivity.Id,
                        CountryId = adhocfileActivity.CountryId,
                        AdhocFileNumber = adhocfileActivity.AdhocFileNumber.ToUpper().Trim(),
                        AdhocContainer = adhocfileActivity.AdhocContainer.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.AdhocFile.Add(adhocfile);
                }


                foreach (AdhocFileActivityLogItem log in adhocfileActivity.AdhocFileActivities)
                {
                    _context.AdhocFileActivityLog.Add(new AdhocFileActivityLog
                    {
                        Id = log.Id,
                        AdhocFileId = adhocfile.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocfileActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [HttpGet]
        public IActionResult AdhocHBLActivity()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Adhoc" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult AdhocHBLActivity(AdhocHBLActivityModel adhocHBLActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocHBL adhochbl = _context.AdhocHBL.Where(x => x.AdhocBooking == adhocHBLActivity.AdhocBooking.ToUpper().Trim() || x.AdhocHBLNumber == adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhochbl == null)
                {
                    adhochbl = new AdhocHBL
                    {
                        Id = adhocHBLActivity.Id,
                        AdhocCountryId = adhocHBLActivity.AdhocCountryId,
                        AdhocBooking = adhocHBLActivity.AdhocBooking.ToUpper().Trim(),
                        AdhocHBLNumber = adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false

                    };
                    _context.AdhocHBL.Add(adhochbl);
                }

                foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                {
                    _context.AdhocHBLActivityLog.Add(new AdhocHBLActivityLog
                    {
                        Id = log.Id,
                        AdhocHBLId = adhochbl.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocHBLActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [HttpPost]
        public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocFileActivityLog
            .Join(_context.AdhocFile, fileActivity => fileActivity.AdhocFileId, fileMaster => fileMaster.Id, (fileActivity, fileMaster) => new { fileActivity, fileMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.fileActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.fileActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.fileMaster.CountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.fileActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocFileDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                FileNumber = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocFileNumber,
                Container = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocContainer,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.fileActivity.EndDate,
                LastFileHandler = User.UserName
            })
            .GroupBy(x => x.FileNumber)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.Container.Contains(container));
            }
            int filteredrecords = data.Count();

            List<AdhocFileDashModel> files = data.Select(
                x => new AdhocFileDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();


            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });


        }

        [HttpPost]
        public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string booking, string hblNumber)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocHBLActivityLog
            .Join(_context.AdhocHBL, hblActivity => hblActivity.AdhocHBLId, hblMaster => hblMaster.Id, (hblActivity, hblMaster) => new { hblActivity, hblMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.hblActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.hblActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.hblMaster.AdhocCountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.hblActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocHBLDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                HBLNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocHBLNumber,
                BookingNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocBooking,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.hblActivity.EndDate,
                LastHBLHandler = User.UserName
            })
            .GroupBy(x => x.HBLNo)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "--Select--")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(booking))
            {
                data = data.Where(x => x.BookingNo.Contains(booking));
            }
            if (!string.IsNullOrEmpty(hblNumber))
            {
                data = data.Where(x => x.HBLNo.Contains(hblNumber));
            }

            int filteredrecords = data.Count();

            List<AdhocHBLDashModel> files = data.Select(
                x => new AdhocHBLDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    BookingNo = x.BookingNo,
                    HBLNo = x.HBLNo,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        [HttpPost]
        public ActionResult UpdateHBLStatus(string hblId, string? newStatusId, string activityName)
        {
            bool statusUpdateSuccessful = false;

            // Perform the status update in your database
            // Assuming you have a service or repository to handle data operations
            // Here, you should replace it with your actual data update logic
            var activityId = _context.ActivityMaster.Where(x => x.NameOfActivity == activityName && x.IsDelete == false && x.IsActive == true).FirstOrDefault()?.Id;
            var hblLog = _context.HBLActivityLog.Where(x => x.HBLId == hblId && x.ActivityId == activityId).FirstOrDefault();
            _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
            {
                HBLogId = hblLog.Id,
                ActivityId = hblLog.ActivityId,
                StatusId = hblLog.StatusId,
                UserId = hblLog.UserId == null ? null : hblLog.UserId,
                StartDate = hblLog.StartDate,
                EndDate = hblLog.EndDate,
                Comment = hblLog.Comment,
            }); 
            _context.SaveChanges();

            if (hblLog != null)
            {
                hblLog.StatusId = newStatusId;
                hblLog.StartDate = DateTime.UtcNow;
                hblLog.EndDate = DateTime.UtcNow.AddMinutes(2.0);
                _context.HBLActivityLog.Update(hblLog);
                _context.SaveChanges();
                statusUpdateSuccessful = true;
            }
            if (statusUpdateSuccessful)
            {
                // Return a success response (if needed)
                return Json("Success");
            }
            else
            {
                // Return an error response (if needed)
                return Json("Error");
            }
        }

        [HttpGet]
        public IActionResult SelectRole()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["AssignedRoles"] = _context.UserRoles.Where(x => x.UserId == userid).Select(x => new RoleNameList
            {
                RoleId = x.RoleId,
                RoleName = _context.Roles.Where(y => y.Id == x.RoleId).Select(x => x.Name).FirstOrDefault()

            }).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult RoleAction(string RoleName)
        {
            if (RoleName.ToUpper().ToString() == "SUPERVISOR" || RoleName.ToUpper().ToString() == "MANAGER")
            {
                return RedirectToAction("Index", "Dashboard");
            }
            else if (RoleName.ToUpper().ToString() == "USER")
            {
                return RedirectToAction("UserThread", "User");
            }
            else
            {
                return NotFound();
            }
            return View();
        }

    }
}
