﻿using Microsoft.AspNetCore.Identity;

namespace APACExportTrackX.DataModel
{
	public class Role : IdentityRole
	{
		public override string Id { get; set; } = Guid.NewGuid().ToString();
		public override string Name { get; set; }
		public override string? NormalizedName { get; set; }
		public bool? IsActive { get; set; } = true;
		public bool? IsDelete { get; set; } = false;
	}
}
