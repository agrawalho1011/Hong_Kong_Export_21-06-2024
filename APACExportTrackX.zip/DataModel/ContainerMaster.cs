﻿using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{
    public class ContainerMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? ContainerNo { get; set; }
        public string FileId { get; set; } = null!;
        public DateTime? SICutOff { get; set; }
        


        [ForeignKey("FileId")]
        public virtual FileMaster FileMaster { get; set; }
        public virtual ICollection<FileActivityLog> FileActivityLogs { get; } = new List<FileActivityLog>();
        public virtual ICollection<HBLMaster> HBLMasters { get; } = new List<HBLMaster>();
    }
}
