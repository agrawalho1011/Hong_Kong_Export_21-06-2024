﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APACExportTrackX.Migrations
{
    public partial class totallbl : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            

            migrationBuilder.RenameColumn(
                name: "TotalHBL",
                table: "FileMaster",
                newName: "TotalBL");

            migrationBuilder.AddColumn<int>(
                name: "TotalHBL",
                table: "HBLMaster",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TotalLBL",
                table: "HBLMaster",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TotalTBL",
                table: "HBLMaster",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TotalHBL",
                table: "HBLMaster");

            migrationBuilder.DropColumn(
                name: "TotalLBL",
                table: "HBLMaster");

            migrationBuilder.DropColumn(
                name: "TotalTBL",
                table: "HBLMaster");

            migrationBuilder.RenameColumn(
                name: "TotalBL",
                table: "FileMaster",
                newName: "TotalHBL");

            migrationBuilder.AddColumn<int>(
                name: "LBL",
                table: "FileMaster",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TBL",
                table: "FileMaster",
                type: "int",
                nullable: true);
        }
    }
}
