﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APACExportTrackX.Migrations
{
    public partial class AddAMSStatusAndAMSDetailsinHBLMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AMSDetails",
                table: "HBLMaster",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AMSStatus",
                table: "HBLMaster",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AMSDetails",
                table: "HBLMaster");

            migrationBuilder.DropColumn(
                name: "AMSStatus",
                table: "HBLMaster");
        }
    }
}
