﻿namespace APACExportTrackX.ViewModels
{
    public class FileReportViewModel
    {
        public DateTime? EnterDate { get; set; }
        public string FileNumber { get; set; }
        public string? ContainerNo { get; set; }
        public DateTime? SICutOff { get; set; }
        public string? UserId { get; set; }
        public string? ActivityId { get; set; }
        public string? StatusId { get; set; }
        public string? Comment { get; set; }
        public string? Roe { get; set; }
        

    }
}
