﻿namespace APACExportTrackX.ViewModels
{
    public class HBLActivityLogsListViewModel
    {
        public string Id { get; set; } 
        public string HBLNumber { get; set; }
        public string Activity { get; set; }
        public string Status { get; set; }
        public string? Comment { get; set; }
        public string? User { get; set; } = null!;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
